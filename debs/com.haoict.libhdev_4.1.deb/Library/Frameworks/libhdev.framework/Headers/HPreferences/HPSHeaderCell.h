#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import "../HUtilities/HCommon.h"
#import "HPSRootListController.h"

@interface HPSHeaderCell : UITableViewCell
@end
