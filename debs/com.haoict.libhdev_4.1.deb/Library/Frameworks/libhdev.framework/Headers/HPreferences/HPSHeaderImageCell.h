#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import "../HUtilities/HCommon.h"

@interface HPSHeaderImageCell : UITableViewCell
@end
